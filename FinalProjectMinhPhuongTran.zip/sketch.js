// ============================================================
//  STELLAR VORTEX
//  Interactive 3D Starfield with Anaglyph Effect
//  By Minh Phuong Tran  |  Final Project  |  Spring 2026
//
//  Controls:
//    Mouse Move  -  Tilt the starfield
//    Click       -  Add a star at mouse position
//    C           -  Change color theme
//    Space       -  Pause / Resume
//    R           -  Reset all stars
//
//  Requires lib/p5.js and lib/p5.anaglyph.min.js
// ============================================================


//Canvas size
let W = 600;
let H = 600;

// -- Anaglyph object --
let ag;

//Star arrays
let sX   = [];   // x position
let sY   = [];   // y position
let sZ   = [];   // depth: -300 = far, 300 = close
let sSpd = [];   // speed toward viewer each frame
let sSz  = [];   // base size of the star

//Settings
let NUM_STARS = 200;
let paused    = false;
let theme     = 0;

//Color themes
let colors = [
  [255, 255, 255],   // white
  [255, 175, 50],    // amber
  [50,  200, 255],   // blue
  [140, 255, 100]    // green
];
let colorNames = ["White", "Amber", "Blue", "Green"];


//  SETUP
function setup() {
  createCanvas(W, H, WEBGL);
  frameRate(90 );          // Lab 3 - frameRate
  colorMode(RGB, 255);    // Lab 2 - colorMode RGB, all channels 0-255

  ag = createAnaglyph(this);

  // Fill star arrays using a for loop (Lab 5 + 6)
  for (let i = 0; i < NUM_STARS; i++) {
    sX.push(random(-W / 2, W / 2));   // Lab 7 - push()
    sY.push(random(-H / 2, H / 2));
    sZ.push(random(-300, 300));
    sSpd.push(random(0.5, 3));
    sSz.push(random(2, 7));
  }

  console.log("Stars created. Total: " + sX.length);  // Lab 6
}



//  DRAW  (runs every frame)
function draw() {
  ag.draw(scene);

  if (!paused) {
    // Move every star closer each frame (Lab 5 - for loop)
    for (let i = 0; i < sX.length; i++) {
      sZ[i] = sZ[i] + sSpd[i];

      // Reset star when it passes the viewer (Lab 4 - if)
      if (sZ[i] > 300) {
        sX[i] = random(-W / 2, W / 2);
        sY[i] = random(-H / 2, H / 2);
        sZ[i] = -300;
      }
    }
  }
}



//  SCENE  - anaglyph library calls this; draw via pg
function scene(pg) {
  pg.colorMode(RGB, 255);  // match main canvas colorMode on pg
  pg.background(0);

  // Tilt view with mouse (Lab 3 - mouseX, mouseY)
  let tiltX = map(mouseY, 0, H, -0.25, 0.25);
  let tiltY = map(mouseX, 0, W, -0.25, 0.25);
  pg.rotateX(tiltX);
  pg.rotateY(tiltY);

  // Draw every star
  let c = colors[theme];

  for (let i = 0; i < sX.length; i++) {
    // Size and brightness grow as stars approach (Lab 3 - map)
    let sz    = map(sZ[i], -300, 300, 0.5, sSz[i] * 2.5);
    let alpha = map(sZ[i], -300, 300, 25, 255);   // 0-255 range

    pg.push();
    pg.translate(sX[i], sY[i], sZ[i]);
    pg.noStroke();                      // Lab 1 - noStroke
    pg.fill(c[0], c[1], c[2], alpha); // Lab 2 - RGBA fill
    pg.ellipse(0, 0, sz, sz);         // Lab 1 - ellipse
    pg.pop();
  }
}



//  KEYBOARD INPUT
function keyPressed() {
  if (key === "c" || key === "C") {
    theme = (theme + 1) % colors.length;
    console.log("Theme: " + colorNames[theme]);
  }

  if (key === " ") {
    if (paused) {
      paused = false;
    } else {
      paused = true;
    }
  }

  if (key === "r" || key === "R") {
    // Clear and refill arrays
    sX = []; sY = []; sZ = []; sSpd = []; sSz = [];

    for (let i = 0; i < NUM_STARS; i++) {
      sX.push(random(-W / 2, W / 2));
      sY.push(random(-H / 2, H / 2));
      sZ.push(random(-300, 300));
      sSpd.push(random(0.5, 3));
      sSz.push(random(2, 7));
    }
    console.log("Reset. Stars: " + sX.length);
  }

  return false;
}

//  MOUSE INPUT  
function mousePressed() {
  // Add a star where user clicked (Lab 7 - push())
  sX.push(mouseX - W / 2);    // Lab 3 - mouseX
  sY.push(mouseY - H / 2);    // Lab 3 - mouseY
  sZ.push(0);
  sSpd.push(random(1, 4));
  sSz.push(random(4, 10));

  console.log("Star added! Total: " + sX.length);
}